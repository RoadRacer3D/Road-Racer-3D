package com.example.racing3d
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
class MainActivity: Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
 window.decorView.systemUiVisibility = 5894 or 1024 or 512
 val w=WebView(this); w.settings.javaScriptEnabled=true; w.webViewClient=WebViewClient()
 w.loadUrl("file:///android_asset/index.html"); setContentView(w)
 }
}